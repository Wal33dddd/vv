# 69phisher
Phishing using try.cloudflare tunnel &amp; undetectable by chrome.
<p align="center">A beginners friendly, Automated phishing tool with 30+ templates.</p>

##

<h3><p align="center">Disclaimer</p></h3>

<i>Any actions and or activities related to <b>69phisher(from zphisher)</b> is solely your responsibility. The misuse of this toolkit can result in <b>criminal charges</b> brought against the persons in question. <b>The contributors will not be held responsible</b> in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.

<b>This toolkit contains materials that can be potentially damaging or dangerous for social media</b>. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

<b>This Tool is made for educational purposes only</b>. Do not attempt to violate the law with anything contained here. <b>If this is your intention, then Get the hell out of here</b>!

It only demonstrates "how phishing works". <b>You shall not misuse the information to gain unauthorized access to someones social media</b>. However you may try out this at your own risk.</i>

##

### Features

- Latest and updated login pages.
- Mask URL support 
- Beginners friendly
- Tunneling options
  - Localhost (visit 127.0.0.1:8080)
  - Cloudflared (default and automated)


### Installation

- Just, Clone this repository -
```
$ git clone git://github.com/Akshay-Arjun/69phisher.git
```

- Change to cloned directory and run `69phisher.sh` -
```
$ cd 69phisher
$ chmod 777 69phisher.sh
$ bash 69phisher.sh
```
- ### Dependencies

**`69phisher`** requires following programs to run properly - 
- `php`
- `wget`
- `curl`
- `git`

> All the dependencies will be installed automatically when you run `69phisher` for the first time.

> Supported Platform : **`Termux`**, **`Ubuntu/Debian/Kali/Parrot`**, **`Arch Linux/Manjaro`**, **`Fedora`**
### Special Thanks :

- [**htr-tech**](https://github.com/htr-tech)

